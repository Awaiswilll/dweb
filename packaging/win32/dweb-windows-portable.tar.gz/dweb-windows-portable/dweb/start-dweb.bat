@echo off
title dweb OS
echo.
echo ========================================
echo   dweb OS - Decentralized Development
echo ========================================
echo.
echo Starting dweb server...
echo Open http://localhost:49737 in your browser
echo.
echo Press Ctrl+C to stop
echo.
cd /d "%~dp0"
node dweb.cjs
pause
