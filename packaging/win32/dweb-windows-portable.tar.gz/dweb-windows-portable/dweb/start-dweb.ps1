$Host.UI.RawUI.WindowTitle = "dweb OS"
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  dweb OS - Decentralized Development" -ForegroundColor White
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Starting dweb server..." -ForegroundColor Yellow
Write-Host "Open http://localhost:49737 in your browser" -ForegroundColor Green
Write-Host ""
Write-Host "Press Ctrl+C to stop" -ForegroundColor Gray
Write-Host ""

Set-Location $PSScriptRoot
& node "dweb.cjs"
