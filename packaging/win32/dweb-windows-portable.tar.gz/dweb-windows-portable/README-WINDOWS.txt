dweb OS - Windows Portable Distribution
========================================

QUICK START:
1. Install Node.js from https://nodejs.org (LTS version)
2. Double-click "dweb\start-dweb.bat" or "dweb\start-dweb.ps1"
3. Open http://localhost:49737 in your browser

WSL DISTRO (Alternative):
1. Open PowerShell as Administrator
2. Run: wsl --import dweb C:\dweb-wsl dweb-wsl-rootfs.tar.gz --version 2
3. Run: wsl -d dweb
4. Open http://localhost:49737

REQUIREMENTS:
- Windows 10/11
- Node.js 18+ (for portable version)
- OR WSL2 enabled (for WSL distro version)

LICENSE:
MIT - Copyright (c) 2026 Dr Awais Javed (Cyberion)

GITHUB:
https://github.com/Awaiswilll/dweb
