Write-Host "Starting dweb OS..." -ForegroundColor Cyan
Write-Host "Open http://localhost:49737 in your browser" -ForegroundColor Yellow
Write-Host ""

Start-Process "http://localhost:49737"

$scriptDir = Split-Path $MyInvocation.MyCommand.Path -Parent
Set-Location $scriptDir

& node "tools\dweb-server.cjs"
