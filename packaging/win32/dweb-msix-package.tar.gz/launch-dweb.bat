@echo off
echo Starting dweb OS...
echo.
echo Open http://localhost:49737 in your browser
echo.
cd /d "%~dp0"
start "" http://localhost:49737
node tools\dweb-server.cjs
